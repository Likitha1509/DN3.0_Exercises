@Component
public class CustomerModelAssembler extends RepresentationModelAssemblerSupport<Customer, EntityModel<Customer>> {

    public CustomerModelAssembler() {
        super(CustomerController.class, EntityModel.class);
    }

    @Override
    public EntityModel<Customer> toModel(Customer customer) {
        return EntityModel.of(customer,
                linkTo(methodOn(CustomerController.class).getCustomer(customer.getId())).withSelfRel(),
                linkTo(methodOn(CustomerController.class).getAllCustomers()).withRel("customers"));
    }
}
