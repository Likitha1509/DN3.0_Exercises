import org.springframework.http.MediaType;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/books")
public class BookController {

    @GetMapping(value = "/{id}", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public EntityModel<Book> getBook(@PathVariable Long id) {
        Book book = bookService.getBook(id);
        return new BookModel(book);
    }

    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public CollectionModel<EntityModel<Book>> getAllBooks() {
        List<EntityModel<Book>> books = bookService.getAllBooks().stream()
                .map(BookModel::new)
                .collect(Collectors.toList());
        return CollectionModel.of(books,
                linkTo(methodOn(BookController.class).getAllBooks()).withSelfRel());
    }

    // Other CRUD methods...
}
