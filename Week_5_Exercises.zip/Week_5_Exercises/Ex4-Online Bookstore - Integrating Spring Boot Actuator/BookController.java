@RestController
@RequestMapping("/api/books")
public class BookController {

    private final CustomMetrics customMetrics;

    public BookController(CustomMetrics customMetrics) {
        this.customMetrics = customMetrics;
    }

    @GetMapping("/{id}")
    public EntityModel<Book> getBook(@PathVariable Long id) {
        customMetrics.recordCustomMetric();
        Book book = bookService.getBook(id);
        return new BookModel(book);
    }

    // Other CRUD methods...
}
