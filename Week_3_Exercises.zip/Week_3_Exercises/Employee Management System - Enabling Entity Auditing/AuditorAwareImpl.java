package com.example.EmployeeManagementSystem.config;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class AuditorAwareImpl implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        // For simplicity, we'll just return a fixed username. In a real application,
        // this would be the authenticated user from the security context.
        return Optional.of("system"); // Replace with actual user retrieval logic
    }
}
