package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.dto.EmployeeNameEmailDTO;
import com.example.EmployeeManagementSystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Use class-based projection to fetch only name and email
    @Query("SELECT new com.example.EmployeeManagementSystem.dto.EmployeeNameEmailDTO(e.name, e.email) FROM Employee e")
    List<EmployeeNameEmailDTO> findAllEmployeeNameAndEmail();
}
