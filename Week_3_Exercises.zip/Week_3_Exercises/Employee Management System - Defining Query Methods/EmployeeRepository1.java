package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Custom query using @Query annotation to find employees by department name
    @Query("SELECT e FROM Employee e WHERE e.department.name = ?1")
    List<Employee> findByDepartmentName(String departmentName);

    // Custom query using @Query annotation to find employees by name starting with a specific prefix
    @Query("SELECT e FROM Employee e WHERE e.name LIKE ?1%")
    List<Employee> findByNameStartingWith(String prefix);
}
