import java.util.Scanner;

public class EmployeeManagementSystem {
    private Employee[] employees;
    private int count;

    public EmployeeManagementSystem(int size) {
        employees = new Employee[size];
        count = 0;
    }

    public void addEmployee(Employee employee) {
        if (count < employees.length) {
            employees[count++] = employee;
            System.out.println("Employee added: " + employee);
        } else {
            System.out.println("Array is full. Cannot add more employees.");
        }
    }

    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    public void traverseEmployees() {
        for (int i = 0; i < count; i++) {
            System.out.println(employees[i]);
        }
    }

    public void deleteEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                employees[i] = employees[count - 1];
                employees[count - 1] = null;
                count--;
                System.out.println("Employee deleted with employeeId: " + employeeId);
                return;
            }
        }
        System.out.println("Employee not found with employeeId: " + employeeId);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of employees the system can hold:");
        int size = scanner.nextInt();
        scanner.nextLine(); // consume newline

        EmployeeManagementSystem ems = new EmployeeManagementSystem(size);

        while (true) {
            System.out.println("Choose an operation: add, search, traverse, delete, exit");
            String operation = scanner.nextLine();
            if (operation.equals("exit")) {
                break;
            }
            switch (operation) {
                case "add":
                    System.out.println("Enter employeeId, name, position, salary:");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    String name = scanner.nextLine();
                    String position = scanner.nextLine();
                    double salary = scanner.nextDouble();
                    scanner.nextLine(); // consume newline
                    Employee employee = new Employee(id, name, position, salary);
                    ems.addEmployee(employee);
                    break;
                case "search":
                    System.out.println("Enter employeeId to search:");
                    id = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    Employee foundEmployee = ems.searchEmployee(id);
                    if (foundEmployee != null) {
                        System.out.println("Employee found: " + foundEmployee);
                    } else {
                        System.out.println("Employee not found with employeeId: " + id);
                    }
                    break;
                case "traverse":
                    ems.traverseEmployees();
                    break;
                case "delete":
                    System.out.println("Enter employeeId to delete:");
                    id = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    ems.deleteEmployee(id);
                    break;
                default:
                    System.out.println("Invalid operation!");
            }
        }
        scanner.close();
    }
}
