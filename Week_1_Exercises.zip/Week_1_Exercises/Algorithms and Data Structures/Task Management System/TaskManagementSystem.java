import java.util.Scanner;

class Node {
    Task task;
    Node next;

    Node(Task task) {
        this.task = task;
        this.next = null;
    }
}

public class TaskManagementSystem {
    private Node head;

    public TaskManagementSystem() {
        this.head = null;
    }

    // Add a new task
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        System.out.println("Task added: " + task);
    }

    // Search for a task
    public Task searchTask(int taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId() == taskId) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    // Traverse the list and display tasks
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    // Delete a task
    public void deleteTask(int taskId) {
        if (head == null) {
            System.out.println("Task list is empty.");
            return;
        }
        if (head.task.getTaskId() == taskId) {
            head = head.next;
            System.out.println("Task deleted with taskId: " + taskId);
            return;
        }
        Node current = head;
        while (current.next != null && current.next.task.getTaskId() != taskId) {
            current = current.next;
        }
        if (current.next == null) {
            System.out.println("Task not found with taskId: " + taskId);
        } else {
            current.next = current.next.next;
            System.out.println("Task deleted with taskId: " + taskId);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TaskManagementSystem tms = new TaskManagementSystem();

        while (true) {
            System.out.println("Choose an operation: add, search, traverse, delete, exit");
            String operation = scanner.nextLine();
            if (operation.equals("exit")) {
                break;
            }
            switch (operation) {
                case "add":
                    System.out.println("Enter taskId, taskName, status:");
                    int taskId = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    String taskName = scanner.nextLine();
                    String status = scanner.nextLine();
                    Task task = new Task(taskId, taskName, status);
                    tms.addTask(task);
                    break;
                case "search":
                    System.out.println("Enter taskId to search:");
                    taskId = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    Task foundTask = tms.searchTask(taskId);
                    if (foundTask != null) {
                        System.out.println("Task found: " + foundTask);
                    } else {
                        System.out.println("Task not found with taskId: " + taskId);
                    }
                    break;
                case "traverse":
                    tms.traverseTasks();
                    break;
                case "delete":
                    System.out.println("Enter taskId to delete:");
                    taskId = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    tms.deleteTask(taskId);
                    break;
                default:
                    System.out.println("Invalid operation!");
            }
        }
        scanner.close();
    }
}
