import java.util.Arrays;
import java.util.Scanner;

public class ECommercePlatform {
    private Product[] products;

    public ECommercePlatform(Product[] products) {
        this.products = products;
    }

    // Linear search
    public Product linearSearch(int productId) {
        for (Product product : products) {
            if (product.getProductId() == productId) {
                return product;
            }
        }
        return null;
    }

    // Binary search
    public Product binarySearch(int productId) {
        int left = 0;
        int right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (products[mid].getProductId() == productId) {
                return products[mid];
            } else if (products[mid].getProductId() < productId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number of products:");
        int n = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Product[] products = new Product[n];
        
        for (int i = 0; i < n; i++) {
            System.out.println("Enter productId, productName, category:");
            int id = scanner.nextInt();
            scanner.nextLine(); // consume newline
            String name = scanner.nextLine();
            String category = scanner.nextLine();
            products[i] = new Product(id, name, category);
        }
        
        // Sort products for binary search
        Arrays.sort(products, (p1, p2) -> Integer.compare(p1.getProductId(), p2.getProductId()));
        
        ECommercePlatform platform = new ECommercePlatform(products);
        
        while (true) {
            System.out.println("Choose a search method: linear, binary, exit");
            String method = scanner.nextLine();
            if (method.equals("exit")) {
                break;
            }
            
            System.out.println("Enter productId to search:");
            int id = scanner.nextInt();
            scanner.nextLine(); // consume newline
            
            Product result = null;
            switch (method) {
                case "linear":
                    result = platform.linearSearch(id);
                    break;
                case "binary":
                    result = platform.binarySearch(id);
                    break;
                default:
                    System.out.println("Invalid search method!");
            }
            
            if (result != null) {
                System.out.println("Product found: " + result);
            } else {
                System.out.println("Product not found!");
            }
        }
        scanner.close();
    }
}
