import java.util.Scanner;

public class FinancialForecasting {

    public static double calculateFutureValue(double presentValue, double growthRate, int periods) {
        if (periods == 0) {
            return presentValue;
        }
        return calculateFutureValue(presentValue * (1 + growthRate), growthRate, periods - 1);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the present value:");
        double presentValue = scanner.nextDouble();

        System.out.println("Enter the annual growth rate (in decimal, e.g., 0.05 for 5%):");
        double growthRate = scanner.nextDouble();

        System.out.println("Enter the number of periods (years):");
        int periods = scanner.nextInt();

        double futureValue = calculateFutureValue(presentValue, growthRate, periods);
        System.out.printf("The future value after %d periods is: %.2f%n", periods, futureValue);

        scanner.close();
    }
}
