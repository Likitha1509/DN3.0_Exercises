import java.util.HashMap;
import java.util.Scanner;

public class InventoryManagementSystem {
    private HashMap<Integer, Product> inventory;

    public InventoryManagementSystem() {
        inventory = new HashMap<>();
    }

    public void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
        System.out.println("Product added: " + product);
    }

    public void updateProduct(int productId, int quantity, double price) {
        Product product = inventory.get(productId);
        if (product != null) {
            product.setQuantity(quantity);
            product.setPrice(price);
            System.out.println("Product updated: " + product);
        } else {
            System.out.println("Product not found!");
        }
    }

    public void deleteProduct(int productId) {
        Product removedProduct = inventory.remove(productId);
        if (removedProduct != null) {
            System.out.println("Product deleted: " + removedProduct);
        } else {
            System.out.println("Product not found!");
        }
    }

    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Choose an operation: add, update, delete, exit");
            String operation = scanner.nextLine();
            if (operation.equals("exit")) {
                break;
            }
            switch (operation) {
                case "add":
                    System.out.println("Enter productId, productName, quantity, price:");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    String name = scanner.nextLine();
                    int qty = scanner.nextInt();
                    double price = scanner.nextDouble();
                    scanner.nextLine(); // consume newline
                    Product product = new Product(id, name, qty, price);
                    ims.addProduct(product);
                    break;
                case "update":
                    System.out.println("Enter productId, new quantity, new price:");
                    id = scanner.nextInt();
                    qty = scanner.nextInt();
                    price = scanner.nextDouble();
                    scanner.nextLine(); // consume newline
                    ims.updateProduct(id, qty, price);
                    break;
                case "delete":
                    System.out.println("Enter productId:");
                    id = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    ims.deleteProduct(id);
                    break;
                default:
                    System.out.println("Invalid operation!");
            }
        }
        scanner.close();
    }
}
