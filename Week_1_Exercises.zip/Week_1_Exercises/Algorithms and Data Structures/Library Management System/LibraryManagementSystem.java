import java.util.Arrays;
import java.util.Scanner;

public class LibraryManagementSystem {
    private Book[] books;
    private int count;

    public LibraryManagementSystem(int size) {
        books = new Book[size];
        count = 0;
    }

    // Add a new book
    public void addBook(Book book) {
        if (count < books.length) {
            books[count++] = book;
            System.out.println("Book added: " + book);
        } else {
            System.out.println("Library is full. Cannot add more books.");
        }
    }

    // Linear search by title
    public Book linearSearchByTitle(String title) {
        for (int i = 0; i < count; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }

    // Binary search by title (assuming books are sorted by title)
    public Book binarySearchByTitle(String title) {
        Arrays.sort(books, 0, count, (b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));
        int left = 0, right = count - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int cmp = books[mid].getTitle().compareToIgnoreCase(title);
            if (cmp == 0) {
                return books[mid];
            } else if (cmp < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of books the library can hold:");
        int size = scanner.nextInt();
        scanner.nextLine(); // consume newline

        LibraryManagementSystem lms = new LibraryManagementSystem(size);

        while (true) {
            System.out.println("Choose an operation: add, linearSearch, binarySearch, exit");
            String operation = scanner.nextLine();
            if (operation.equals("exit")) {
                break;
            }
            switch (operation) {
                case "add":
                    System.out.println("Enter bookId, title, author:");
                    int bookId = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    String title = scanner.nextLine();
                    String author = scanner.nextLine();
                    Book book = new Book(bookId, title, author);
                    lms.addBook(book);
                    break;
                case "linearSearch":
                    System.out.println("Enter title to search (linear):");
                    title = scanner.nextLine();
                    Book foundBookLinear = lms.linearSearchByTitle(title);
                    if (foundBookLinear != null) {
                        System.out.println("Book found: " + foundBookLinear);
                    } else {
                        System.out.println("Book not found with title: " + title);
                    }
                    break;
                case "binarySearch":
                    System.out.println("Enter title to search (binary):");
                    title = scanner.nextLine();
                    Book foundBookBinary = lms.binarySearchByTitle(title);
                    if (foundBookBinary != null) {
                        System.out.println("Book found: " + foundBookBinary);
                    } else {
                        System.out.println("Book not found with title: " + title);
                    }
                    break;
                default:
                    System.out.println("Invalid operation!");
            }
        }
        scanner.close();
    }
}
