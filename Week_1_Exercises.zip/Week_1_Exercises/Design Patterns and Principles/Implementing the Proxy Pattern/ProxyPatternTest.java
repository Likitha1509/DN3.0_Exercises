import java.util.Scanner;

public class ProxyPatternTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the filename of the image to display:");
        String filename = scanner.nextLine();

        Image image = new ProxyImage(filename);

        while (true) {
            System.out.println("Type 'display' to display the image or 'exit' to quit:");
            String command = scanner.nextLine().trim().toLowerCase();

            if (command.equals("exit")) {
                break;
            } else if (command.equals("display")) {
                image.display();
            } else {
                System.out.println("Unknown command. Please type 'display' or 'exit'.");
            }
        }

        scanner.close();
    }
}
