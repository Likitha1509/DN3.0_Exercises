import java.util.Scanner;

public class DependencyInjectionTest {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        CustomerService customerService = new CustomerService(customerRepository);

        System.out.print("Enter Customer ID to find: ");

        int id = scanner.nextInt();

        String result = customerService.getCustomer(id);

        System.out.println(result);

        scanner.close();
    }
}