public interface CustomerRepository {
    String findCustomerById(int id);
}

public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public String findCustomerById(int id) {
        if (id == 1) {
            return "Customer ID: 1, Name: John Doe, Email: john.doe@example.com";
        } else if (id == 2) {
            return "Customer ID: 2, Name: Jane Smith, Email: jane.smith@example.com";
        } else {
            return "Customer with ID: " + id + " not found!";
        }
    }
}

public class CustomerService {
    private CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public String getCustomer(int id) {
        return customerRepository.findCustomerById(id);
    }
}