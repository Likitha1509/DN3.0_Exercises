import java.util.Scanner;

public class AdapterPatternTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PaymentProcessor processor = null;

        while (true) {
            System.out.println("Enter payment gateway (paypal, stripe, square) or 'exit' to quit:");
            String gateway = scanner.nextLine().trim().toLowerCase();

            if (gateway.equals("exit")) {
                break;
            }

            System.out.println("Enter payment amount:");
            double amount = scanner.nextDouble();
            scanner.nextLine();  // Consume newline

            switch (gateway) {
                case "paypal":
                    processor = new PayPalAdapter(new PayPal());
                    break;
                case "stripe":
                    processor = new StripeAdapter(new Stripe());
                    break;
                case "square":
                    processor = new SquareAdapter(new Square());
                    break;
                default:
                    System.out.println("Unknown payment gateway. Please enter 'paypal', 'stripe', or 'square'.");
                    continue;
            }

            if (processor != null) {
                processor.processPayment(amount);
            }
        }

        scanner.close();
    }
}
