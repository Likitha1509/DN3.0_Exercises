import java.util.Scanner;

public class SingletonTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Logger logger = Logger.getInstance();

        while (true) {
            System.out.println("Enter a log message (or type 'exit' to quit):");
            String message = scanner.nextLine();

            if (message.equalsIgnoreCase("exit")) {
                break;
            }

            logger.log(message);
        }

        scanner.close();
    }
}
