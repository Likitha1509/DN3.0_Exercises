import java.util.Scanner;

public class CommandPatternTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Light light = new Light();
        RemoteControl remoteControl = new RemoteControl();

        while (true) {
            System.out.println("Select an action (1: Turn On Light, 2: Turn Off Light, exit to quit):");
            String choice = scanner.nextLine().trim();

            if (choice.equalsIgnoreCase("exit")) {
                break;
            }

            switch (choice) {
                case "1":
                    remoteControl.setCommand(new LightOnCommand(light));
                    remoteControl.pressButton();
                    break;

                case "2":
                    remoteControl.setCommand(new LightOffCommand(light));
                    remoteControl.pressButton();
                    break;

                default:
                    System.out.println("Invalid selection. Please choose 1 or 2.");
            }
        }

        scanner.close();
    }
}
