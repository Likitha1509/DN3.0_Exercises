import java.util.Scanner;

public class FactoryMethodTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DocumentFactory factory = null;

        while (true) {
            System.out.println("Enter document type (word, pdf, excel) or 'exit' to quit:");
            String input = scanner.nextLine().trim().toLowerCase();

            if (input.equals("exit")) {
                break;
            }

            switch (input) {
                case "word":
                    factory = new WordDocumentFactory();
                    break;
                case "pdf":
                    factory = new PdfDocumentFactory();
                    break;
                case "excel":
                    factory = new ExcelDocumentFactory();
                    break;
                default:
                    System.out.println("Unknown document type. Please enter 'word', 'pdf', or 'excel'.");
                    continue;
            }

            Document document = factory.createDocument();
            document.open();
        }

        scanner.close();
    }
}
