import java.util.Scanner;

public class MVCPatternTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Student ID:");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("Enter Student Name:");
        String name = scanner.nextLine();
        System.out.println("Enter Student Grade:");
        double grade = scanner.nextDouble();
        Student student = new Student(id, name, grade);
        StudentView studentView = new StudentView();
        StudentController studentController = new StudentController(student, studentView);
        studentController.updateView();
        System.out.println("Do you want to update the student name? (yes/no)");
        String updateNameResponse = scanner.next();
        if (updateNameResponse.equalsIgnoreCase("yes")) {
            System.out.println("Enter new Student Name:");
            scanner.nextLine(); 
            String newName = scanner.nextLine();
            studentController.setStudentName(newName);
        }
        System.out.println("Do you want to update the student grade? (yes/no)");
        String updateGradeResponse = scanner.next();
        if (updateGradeResponse.equalsIgnoreCase("yes")) {
            System.out.println("Enter new Student Grade:");
            double newGrade = scanner.nextDouble();
            studentController.setStudentGrade(newGrade);
        }
        studentController.updateView();
        scanner.close();
    }
}
