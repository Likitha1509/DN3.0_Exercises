public interface Observer {
    void update(double stockPrice);
}
public class MobileApp implements Observer {
    @Override
    public void update(double stockPrice) {
        System.out.println("Mobile App: Stock price updated to $" + stockPrice);
    }
}
public class WebApp implements Observer {
    @Override
    public void update(double stockPrice) {
        System.out.println("Web App: Stock price updated to $" + stockPrice);
    }
}
import java.util.Scanner;

public class ObserverPatternTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StockMarket stockMarket = new StockMarket();
        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();
        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        while (true) {
            System.out.println("Enter the new stock price (or type 'exit' to quit):");
            String input = scanner.nextLine().trim();

            if (input.equalsIgnoreCase("exit")) {
                break;
            }

            try {
                double price = Double.parseDouble(input);
                stockMarket.setStockPrice(price);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid stock price.");
            }
        }

        scanner.close();
    }
}
