import java.util.Scanner;

public class StrategyPatternTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PaymentContext paymentContext = new PaymentContext();

        while (true) {
            System.out.println("Select payment method (1: Credit Card, 2: PayPal, exit to quit):");
            String choice = scanner.nextLine().trim();

            if (choice.equalsIgnoreCase("exit")) {
                break;
            }

            System.out.println("Enter amount to pay:");
            double amount = scanner.nextDouble();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case "1":
                    System.out.println("Enter Card Number:");
                    String cardNumber = scanner.nextLine();
                    System.out.println("Enter Card Holder Name:");
                    String cardHolder = scanner.nextLine();
                    PaymentStrategy creditCardPayment = new CreditCardPayment(cardNumber, cardHolder);
                    paymentContext.setPaymentStrategy(creditCardPayment);
                    paymentContext.executePayment(amount);
                    break;

                case "2":
                    System.out.println("Enter PayPal Email:");
                    String email = scanner.nextLine();
                    PaymentStrategy paypalPayment = new PayPalPayment(email);
                    paymentContext.setPaymentStrategy(paypalPayment);
                    paymentContext.executePayment(amount);
                    break;

                default:
                    System.out.println("Invalid selection. Please choose 1 or 2.");
            }
        }

        scanner.close();
    }
}
