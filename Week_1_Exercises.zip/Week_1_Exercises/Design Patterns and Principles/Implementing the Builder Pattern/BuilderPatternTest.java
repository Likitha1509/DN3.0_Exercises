import java.util.Scanner;

public class BuilderPatternTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Computer.ComputerBuilder builder = new Computer.ComputerBuilder();

        System.out.println("Enter CPU:");
        builder.setCPU(scanner.nextLine());

        System.out.println("Enter RAM:");
        builder.setRAM(scanner.nextLine());

        System.out.println("Enter Storage:");
        builder.setStorage(scanner.nextLine());

        System.out.println("Enter Graphics Card:");
        builder.setGraphicsCard(scanner.nextLine());

        System.out.println("Enter Operating System:");
        builder.setOperatingSystem(scanner.nextLine());

        System.out.println("Is Bluetooth Enabled? (true/false):");
        builder.setBluetoothEnabled(scanner.nextBoolean());

        System.out.println("Is Wifi Enabled? (true/false):");
        builder.setWifiEnabled(scanner.nextBoolean());

        // Build the computer object
        Computer computer = builder.build();
        System.out.println(computer);

        scanner.close();
    }
}
