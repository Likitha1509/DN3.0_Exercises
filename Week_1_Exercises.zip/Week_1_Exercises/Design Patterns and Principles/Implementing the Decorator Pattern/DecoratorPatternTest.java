import java.util.Scanner;

public class DecoratorPatternTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Notifier notifier = new EmailNotifier();

        while (true) {
            System.out.println("Choose notification channels (email, sms, slack) or 'send' to proceed:");
            String input = scanner.nextLine().trim().toLowerCase();

            if (input.equals("send")) {
                break;
            }

            switch (input) {
                case "sms":
                    notifier = new SMSNotifierDecorator(notifier);
                    break;
                case "slack":
                    notifier = new SlackNotifierDecorator(notifier);
                    break;
                default:
                    System.out.println("Unknown channel. Please enter 'email', 'sms', or 'slack'.");
                    continue;
            }
        }

        System.out.println("Enter the message to send:");
        String message = scanner.nextLine();

        notifier.send(message);

        scanner.close();
    }
}
