package com.example.bookstore.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.bookstore.model.Book;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/books")
public class BookController {

    private Map<Long, Book> bookStore = new HashMap<>();
    private long counter = 0;

    // Response Status: Use @ResponseStatus to customize HTTP status codes
    @PostMapping("/create")
    @ResponseStatus(HttpStatus.CREATED) // Sets the HTTP status to 201 Created
    public Book createBook(@RequestBody Book book) {
        book.setId(++counter);
        bookStore.put(book.getId(), book);
        return book;
    }

    // Custom Headers: Add custom headers to the response using ResponseEntity
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Book book = bookStore.get(id);
        if (book == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).header("Custom-Header", "Book Not Found").build();
        }
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "Book Found");
        return ResponseEntity.ok().headers(headers).body(book);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        Book book = bookStore.remove(id);
        if (book == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).header("Custom-Header", "Book Not Found").build();
        }
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "Book Deleted Successfully");
        return ResponseEntity.noContent().headers(headers).build();
    }
}
