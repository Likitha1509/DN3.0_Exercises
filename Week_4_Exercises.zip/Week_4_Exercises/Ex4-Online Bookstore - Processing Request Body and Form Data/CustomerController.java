package com.example.bookstore.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.bookstore.model.Customer;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private Map<Long, Customer> customerStore = new HashMap<>();
    private long counter = 0;

    // Request Body: Create a new customer by accepting a JSON request body
    @PostMapping("/create")
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        customer.setId(++counter);
        customerStore.put(customer.getId(), customer);
        return ResponseEntity.status(HttpStatus.CREATED).body(customer);
    }

    // Form Data: Process form data for customer registrations
    @PostMapping("/register")
    public ResponseEntity<Customer> registerCustomer(
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam String phone) {
        Customer customer = new Customer();
        customer.setId(++counter);
        customer.setName(name);
        customer.setEmail(email);
        customer.setPhone(phone);
        customerStore.put(customer.getId(), customer);
        return ResponseEntity.status(HttpStatus.CREATED).body(customer);
    }
}
