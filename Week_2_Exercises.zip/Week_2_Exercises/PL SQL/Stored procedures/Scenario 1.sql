CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest IS
BEGIN
    -- Update the balance of all savings accounts by applying a 1% interest rate
    UPDATE accounts
    SET balance = balance * 1.01
    WHERE account_type = 'SAVINGS';

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        -- Log any error and rollback the transaction
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error processing monthly interest: ' || SQLERRM);
END ProcessMonthlyInterest;
/
