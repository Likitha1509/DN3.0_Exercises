DECLARE
    CURSOR cur_loans IS
        SELECT customer_id, due_date
        FROM loans
        WHERE due_date BETWEEN SYSDATE AND SYSDATE + 30;
    
    v_customer_id loans.customer_id%TYPE;
    v_due_date loans.due_date%TYPE;
BEGIN
    OPEN cur_loans;
    LOOP
        FETCH cur_loans INTO v_customer_id, v_due_date;
        EXIT WHEN cur_loans%NOTFOUND;
        
        -- Print a reminder message for the customer
        DBMS_OUTPUT.PUT_LINE('Reminder: Customer ID ' || v_customer_id || 
                             ', your loan is due on ' || TO_CHAR(v_due_date, 'DD-MON-YYYY') || 
                             '. Please make the necessary arrangements.');
    END LOOP;
    
    CLOSE cur_loans;
END;
/
