DECLARE
    CURSOR cur_customers IS
        SELECT customer_id, balance
        FROM customers
        WHERE balance > 10000;
    
    v_customer_id customers.customer_id%TYPE;
BEGIN
    OPEN cur_customers;
    LOOP
        FETCH cur_customers INTO v_customer_id;
        EXIT WHEN cur_customers%NOTFOUND;
        
        -- Set the IsVIP flag to TRUE
        UPDATE customers
        SET IsVIP = TRUE
        WHERE customer_id = v_customer_id;
    END LOOP;
    
    CLOSE cur_customers;
    COMMIT;
END;
/
