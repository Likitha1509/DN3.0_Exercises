DECLARE
    CURSOR cur_customers IS
        SELECT customer_id, age, loan_interest_rate
        FROM customers
        WHERE age > 60;
    
    v_customer_id customers.customer_id%TYPE;
    v_loan_interest_rate customers.loan_interest_rate%TYPE;
BEGIN
    OPEN cur_customers;
    LOOP
        FETCH cur_customers INTO v_customer_id, v_loan_interest_rate;
        EXIT WHEN cur_customers%NOTFOUND;
        
        -- Apply a 1% discount
        v_loan_interest_rate := v_loan_interest_rate - 1;
        
        -- Update the customer's loan interest rate
        UPDATE customers
        SET loan_interest_rate = v_loan_interest_rate
        WHERE customer_id = v_customer_id;
    END LOOP;
    
    CLOSE cur_customers;
    COMMIT;
END;
/
