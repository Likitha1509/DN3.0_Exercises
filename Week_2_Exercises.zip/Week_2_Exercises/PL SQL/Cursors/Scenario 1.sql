DECLARE
    CURSOR GenerateMonthlyStatements IS
        SELECT c.customer_id, c.name, t.transaction_id, t.amount, t.transaction_date
        FROM customers c
        JOIN transactions t ON c.customer_id = t.customer_id
        WHERE EXTRACT(MONTH FROM t.transaction_date) = EXTRACT(MONTH FROM SYSDATE)
          AND EXTRACT(YEAR FROM t.transaction_date) = EXTRACT(YEAR FROM SYSDATE);
    
    v_customer_id customers.customer_id%TYPE;
    v_customer_name customers.name%TYPE;
    v_transaction_id transactions.transaction_id%TYPE;
    v_amount transactions.amount%TYPE;
    v_transaction_date transactions.transaction_date%TYPE;
BEGIN
    FOR rec IN GenerateMonthlyStatements LOOP
        -- Print the monthly statement for each customer
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || rec.customer_id);
        DBMS_OUTPUT.PUT_LINE('Customer Name: ' || rec.name);
        DBMS_OUTPUT.PUT_LINE('Transaction ID: ' || rec.transaction_id);
        DBMS_OUTPUT.PUT_LINE('Amount: ' || rec.amount);
        DBMS_OUTPUT.PUT_LINE('Transaction Date: ' || rec.transaction_date);
        DBMS_OUTPUT.PUT_LINE('-----------------------------');
    END LOOP;
END;
/
