DECLARE
    CURSOR UpdateLoanInterestRates IS
        SELECT loan_id, interest_rate
        FROM loans;

    v_loan_id loans.loan_id%TYPE;
    v_current_interest_rate loans.interest_rate%TYPE;
    v_new_interest_rate NUMBER; -- Variable to hold the new interest rate
BEGIN
    FOR rec IN UpdateLoanInterestRates LOOP
        v_loan_id := rec.loan_id;
        v_current_interest_rate := rec.interest_rate;

        -- Update the interest rate based on the new policy (e.g., increase by 0.5%)
        v_new_interest_rate := v_current_interest_rate + 0.5;

        -- Update the loan interest rate in the loans table
        UPDATE loans
        SET interest_rate = v_new_interest_rate
        WHERE loan_id = v_loan_id;

        DBMS_OUTPUT.PUT_LINE('Updated Loan ID: ' || v_loan_id || 
                             ' from Interest Rate: ' || v_current_interest_rate ||
                             ' to New Interest Rate: ' || v_new_interest_rate);
    END LOOP;

    COMMIT; -- Commit the changes
END;
/
