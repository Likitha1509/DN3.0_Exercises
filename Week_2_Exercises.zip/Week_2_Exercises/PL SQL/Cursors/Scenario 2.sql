DECLARE
    CURSOR ApplyAnnualFee IS
        SELECT account_id, balance
        FROM accounts;
    
    v_account_id accounts.account_id%TYPE;
    v_balance accounts.balance%TYPE;
    v_annual_fee CONSTANT NUMBER := 50; -- Example fee amount
BEGIN
    FOR rec IN ApplyAnnualFee LOOP
        v_account_id := rec.account_id;
        v_balance := rec.balance;

        -- Deduct the annual maintenance fee from the account balance
        UPDATE accounts
        SET balance = balance - v_annual_fee
        WHERE account_id = v_account_id;

        DBMS_OUTPUT.PUT_LINE('Applied annual fee to Account ID: ' || v_account_id || 
                             '. New Balance: ' || (v_balance - v_annual_fee));
    END LOOP;

    COMMIT; -- Commit the changes
END;
/
