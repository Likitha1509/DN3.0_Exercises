CREATE OR REPLACE PACKAGE BODY CustomerManagement AS

    PROCEDURE AddNewCustomer(
        p_name IN VARCHAR2,
        p_date_of_birth IN DATE,
        p_initial_balance IN NUMBER
    ) IS
    BEGIN
        INSERT INTO customers (name, date_of_birth, created_at)
        VALUES (p_name, p_date_of_birth, SYSDATE);
        
        -- Assuming there's a way to retrieve the last inserted customer_id
        DECLARE
            v_customer_id NUMBER := customers_seq.CURRVAL; -- Assuming a sequence for customer IDs
        BEGIN
            INSERT INTO accounts (customer_id, balance)
            VALUES (v_customer_id, p_initial_balance);
        END;
    END AddNewCustomer;

    PROCEDURE UpdateCustomerDetails(
        p_customer_id IN NUMBER,
        p_name IN VARCHAR2,
        p_date_of_birth IN DATE
    ) IS
    BEGIN
        UPDATE customers
        SET name = p_name,
            date_of_birth = p_date_of_birth,
            LastModified = SYSDATE
        WHERE customer_id = p_customer_id;
    END UpdateCustomerDetails;

    FUNCTION GetCustomerBalance(
        p_customer_id IN NUMBER
    ) RETURN NUMBER IS
        v_balance NUMBER;
    BEGIN
        SELECT SUM(balance) INTO v_balance
        FROM accounts
        WHERE customer_id = p_customer_id;

        RETURN v_balance;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN 0; -- Return 0 if the customer has no accounts
    END GetCustomerBalance;

END CustomerManagement;
/
