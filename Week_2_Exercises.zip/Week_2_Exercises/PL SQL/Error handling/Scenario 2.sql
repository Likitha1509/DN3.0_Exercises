CREATE OR REPLACE PROCEDURE UpdateSalary (
    p_employee_id IN employees.employee_id%TYPE,
    p_percentage IN NUMBER
) AS
BEGIN
    -- Update the salary of the employee
    UPDATE employees
    SET salary = salary * (1 + p_percentage / 100)
    WHERE employee_id = p_employee_id;

    -- Check if any row was updated
    IF SQL%ROWCOUNT = 0 THEN
        RAISE_APPLICATION_ERROR(-20002, 'Employee ID not found.');
    END IF;

    COMMIT;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        -- Log an error message if the employee ID does not exist
        DBMS_OUTPUT.PUT_LINE('Error: Employee ID ' || p_employee_id || ' not found.');

    WHEN OTHERS THEN
        -- Log any other error and rollback the transaction
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error updating salary: ' || SQLERRM);
        
        -- Re-raise the exception if needed
        RAISE;
END UpdateSalary;
/
