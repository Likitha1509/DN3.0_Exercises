CREATE OR REPLACE PROCEDURE AddNewCustomer (
    p_customer_id IN customers.customer_id%TYPE,
    p_name IN customers.name%TYPE,
    p_age IN customers.age%TYPE,
    p_balance IN customers.balance%TYPE
) AS
BEGIN
    -- Insert a new customer into the Customers table
    INSERT INTO customers (customer_id, name, age, balance)
    VALUES (p_customer_id, p_name, p_age, p_balance);

    COMMIT;
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        -- Handle the case where a customer with the same ID already exists
        DBMS_OUTPUT.PUT_LINE('Error: Customer with ID ' || p_customer_id || ' already exists.');
        
    WHEN OTHERS THEN
        -- Log any other error and rollback the transaction
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error adding new customer: ' || SQLERRM);
        
        -- Re-raise the exception if needed
        RAISE;
END AddNewCustomer;
/
