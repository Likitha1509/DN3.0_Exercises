CREATE OR REPLACE TRIGGER CheckTransactionRules
BEFORE INSERT ON transactions
FOR EACH ROW
DECLARE
    v_balance accounts.balance%TYPE;
BEGIN
    -- Get the current balance of the account involved in the transaction
    SELECT balance INTO v_balance
    FROM accounts
    WHERE account_id = :NEW.account_id
    FOR UPDATE;

    -- Check if the transaction is a withdrawal
    IF :NEW.transaction_type = 'WITHDRAWAL' THEN
        -- Ensure withdrawals do not exceed the current balance
        IF :NEW.amount > v_balance THEN
            RAISE_APPLICATION_ERROR(-20001, 'Insufficient balance for the withdrawal.');
        END IF;
    ELSIF :NEW.transaction_type = 'DEPOSIT' THEN
        -- Ensure that deposits are positive amounts
        IF :NEW.amount <= 0 THEN
            RAISE_APPLICATION_ERROR(-20002, 'Deposit amount must be positive.');
        END IF;
    END IF;
END CheckTransactionRules;
/
